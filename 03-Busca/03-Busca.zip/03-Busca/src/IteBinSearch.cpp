//
//  IteBinSearch.cpp
//  Iterative Binary Search
//
//  Created by Eiji Adachi Medeiros Barbosa 
//

#include "Search.hpp"

int search(int v[], int size, int key)
{
    // TO-DO
}
