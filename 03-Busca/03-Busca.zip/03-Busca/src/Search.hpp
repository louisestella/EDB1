//
//  Search.hpp
//
//  Created by Eiji Adachi Medeiros Barbosa 
//

#ifndef Search_hpp
#define Search_hpp

const int NOT_FOUND = -1;

int search(int[], int, int);



#endif /* Search_hpp */
